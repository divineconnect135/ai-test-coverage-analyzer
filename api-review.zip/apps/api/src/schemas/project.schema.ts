import { z } from 'zod'

export const createProjectSchema = z.strictObject({
  name: z
    .string()
    .trim()
    .min(2, 'Project name must contain at least 2 characters.')
    .max(100, 'Project name cannot exceed 100 characters.'),

  description: z
    .string()
    .trim()
    .max(1000, 'Description cannot exceed 1000 characters.')
    .default(''),
})

export type CreateProjectInput = z.infer<typeof createProjectSchema>
